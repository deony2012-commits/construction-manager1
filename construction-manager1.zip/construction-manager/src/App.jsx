import { useState, useMemo, useRef } from "react";

/* ─── CONSTANTS ──────────────────────────────────────────── */
const STEPS = [
  { id: "setup",      label: "Project Setup",   icon: "⬡" },
  { id: "materials",  label: "Materials",        icon: "⬡" },
  { id: "costs",      label: "Cost Estimate",    icon: "⬡" },
  { id: "team",       label: "Team",             icon: "⬡" },
  { id: "procedures", label: "Procedures",       icon: "⬡" },
  { id: "timeline",   label: "Timeline",         icon: "⬡" },
  { id: "risks",      label: "Risk & Quality",   icon: "⬡" },
  { id: "summary",    label: "Summary",          icon: "⬡" },
];

const PROJECT_TYPES = {
  residential: { label: "Residential",  factor: 1.0 },
  commercial:  { label: "Commercial",   factor: 1.45 },
  industrial:  { label: "Industrial",   factor: 1.65 },
  mixed:       { label: "Mixed Use",    factor: 1.3  },
};

// All costs in TZS
const INIT_MATERIALS = [
  { id:"concrete",    label:"Concrete",            unit:"m³",    perSqm:0.45, unitCost:280000  },
  { id:"steel",       label:"Steel Rebar",          unit:"kg",    perSqm:25,   unitCost:3200    },
  { id:"bricks",      label:"Bricks / Blocks",      unit:"units", perSqm:55,   unitCost:850     },
  { id:"sand",        label:"Sand",                 unit:"m³",    perSqm:0.3,  unitCost:75000   },
  { id:"cement",      label:"Cement (50 kg bags)",  unit:"bags",  perSqm:8,    unitCost:28000   },
  { id:"roofing",     label:"Roofing Sheets",       unit:"m²",    perSqm:0.65, unitCost:55000   },
  { id:"windows",     label:"Windows",              unit:"units", perSqm:0.08, unitCost:680000  },
  { id:"doors",       label:"Doors",                unit:"units", perSqm:0.025,unitCost:950000  },
  { id:"electrical",  label:"Electrical Points",    unit:"pts",   perSqm:0.6,  unitCost:180000  },
  { id:"plumbing",    label:"Plumbing Points",      unit:"pts",   perSqm:0.18, unitCost:320000  },
  { id:"tiles",       label:"Floor Tiles",          unit:"m²",    perSqm:0.9,  unitCost:48000   },
  { id:"paint",       label:"Paint",                unit:"litres",perSqm:2.5,  unitCost:12500   },
];

const INIT_PROCEDURES = [
  { id:"planning",   phase:"Pre-Construction", label:"Site Survey & Planning",    days:14, baseCost:5500000,  teamImpact:0.02, desc:"Topographic survey, soil tests, architectural drawings" },
  { id:"permits",    phase:"Pre-Construction", label:"Permits & Approvals",       days:21, baseCost:3800000,  teamImpact:0.01, desc:"Building permits, environmental clearances, council approvals" },
  { id:"clearing",   phase:"Foundation",       label:"Site Clearing & Excavation",days:7,  baseCost:9200000,  teamImpact:0.05, desc:"Land clearing, bulk earthworks, foundation excavation" },
  { id:"foundation", phase:"Foundation",       label:"Foundation Works",          days:21, baseCost:21000000, teamImpact:0.12, desc:"Strip footings, pad footings, slab on ground or pile foundations" },
  { id:"structure",  phase:"Structural",       label:"Structural Framework",      days:35, baseCost:42000000, teamImpact:0.20, desc:"Columns, beams, slabs, load-bearing walls" },
  { id:"roofing",    phase:"Structural",       label:"Roofing Installation",      days:14, baseCost:17500000, teamImpact:0.08, desc:"Roof structure, decking, waterproofing and cladding" },
  { id:"masonry",    phase:"Envelope",         label:"Masonry & Walling",         days:28, baseCost:25000000, teamImpact:0.14, desc:"Internal and external walls, plastering, rendering" },
  { id:"electrical", phase:"MEP",              label:"Electrical Installation",   days:21, baseCost:19000000, teamImpact:0.07, desc:"Wiring, switchboards, lighting, power points" },
  { id:"plumbing",   phase:"MEP",              label:"Plumbing & Drainage",       days:18, baseCost:16500000, teamImpact:0.06, desc:"Water supply, drainage, sanitary fittings" },
  { id:"finishing",  phase:"Finishing",        label:"Interior Finishing",        days:30, baseCost:29000000, teamImpact:0.10, desc:"Tiling, painting, ceiling works, joinery" },
  { id:"external",   phase:"Finishing",        label:"External Works & Landscape",days:14, baseCost:12500000, teamImpact:0.06, desc:"Paving, fencing, drainage, site cleanup" },
  { id:"handover",   phase:"Handover",         label:"Inspection & Handover",     days:7,  baseCost:2800000,  teamImpact:0.01, desc:"Final inspection, snag list, occupation certificate" },
];

const INIT_TEAM = [
  { id:0, role:"Project Manager",   count:1, dailyRate:630000,  phase:"All" },
  { id:1, role:"Site Engineer",     count:1, dailyRate:500000,  phase:"All" },
  { id:2, role:"Foreman",           count:2, dailyRate:320000,  phase:"Structural" },
  { id:3, role:"Mason / Bricklayer",count:4, dailyRate:210000,  phase:"Envelope" },
  { id:4, role:"Carpenter",         count:3, dailyRate:230000,  phase:"Structural" },
  { id:5, role:"Steel Fixer",       count:3, dailyRate:250000,  phase:"Foundation" },
  { id:6, role:"Electrician",       count:2, dailyRate:290000,  phase:"MEP" },
  { id:7, role:"Plumber",           count:2, dailyRate:280000,  phase:"MEP" },
  { id:8, role:"Painter",           count:3, dailyRate:200000,  phase:"Finishing" },
  { id:9, role:"Unskilled Labour",  count:6, dailyRate:120000,  phase:"All" },
  { id:10,role:"Safety Officer",    count:1, dailyRate:340000,  phase:"All" },
];

const RISKS = [
  { id:"r1",  cat:"Site",    label:"Poor soil conditions requiring redesign",            severity:"High",   mitigation:"Conduct thorough geotechnical investigation before design" },
  { id:"r2",  cat:"Site",    label:"Underground utilities conflict",                      severity:"Medium", mitigation:"Survey and map all underground services before excavation" },
  { id:"r3",  cat:"Finance", label:"Material price escalation",                           severity:"High",   mitigation:"Lock in prices with suppliers; maintain 15% contingency" },
  { id:"r4",  cat:"Finance", label:"Client payment delays",                               severity:"High",   mitigation:"Milestone-based payment schedule with signed contract" },
  { id:"r5",  cat:"Labour",  label:"Skilled labour shortage",                             severity:"Medium", mitigation:"Pre-hire key trades; maintain list of backup subcontractors" },
  { id:"r6",  cat:"Labour",  label:"Worker injury on site",                               severity:"High",   mitigation:"Enforce PPE, daily toolbox talks, maintain first aid on site" },
  { id:"r7",  cat:"Weather", label:"Extended rainy season causing delays",                severity:"Medium", mitigation:"Schedule excavation and concrete pours in dry season" },
  { id:"r8",  cat:"Legal",   label:"Permit or regulatory delays",                         severity:"Medium", mitigation:"Apply early; assign dedicated liaison for authorities" },
  { id:"r9",  cat:"Quality", label:"Substandard materials delivered",                     severity:"High",   mitigation:"Require material test certificates; inspect each delivery" },
  { id:"r10", cat:"Quality", label:"Poor workmanship on structural elements",             severity:"High",   mitigation:"Daily QA inspections; hold payments until sign-off" },
];

const QUALITY_CHECKS = {
  "Foundation":      ["Correct excavation depth and width","Blinding concrete laid and level","Reinforcement bar spacing matches drawings","No contamination in concrete pour","Curing period observed (min 7 days)"],
  "Structural":      ["Column starter bars correctly positioned","Formwork adequately propped","Concrete mix design approved by engineer","Slab thickness checked before pour","Post-pour curing completed"],
  "Envelope":        ["Wall plumb and level checked every 5 courses","Mortar joints uniform and fully filled","Lintel sizes match opening widths","DPC/DPM installed at correct level","External render applied in 2 coats"],
  "MEP":             ["All conduits installed before plastering","Pipe pressure test completed","Earthing and bonding verified","Hot & cold water tested for leaks","Distribution board labelled and signed off"],
  "Finishing":       ["Tile adhesion tested – no hollow spots","Paint adhesion adequate, no peeling","All doors and windows operate freely","Skirting and cornices aligned","Final clean completed before handover"],
};

const PHASE_COLORS = {
  "Pre-Construction":"#185FA5",
  "Foundation":      "#963C1D",
  "Structural":      "#3B6D11",
  "Envelope":        "#854F0B",
  "MEP":             "#533AB7",
  "Finishing":       "#0F6E56",
  "Handover":        "#5F5E5A",
};
const PHASES = Object.keys(PHASE_COLORS);

/* ─── HELPERS ────────────────────────────────────────────── */
function tzs(n){ return "TZS " + Math.round(n).toLocaleString("en-TZ"); }
function fmtN(n,d=0){ return parseFloat(n.toFixed(d)).toLocaleString(); }
function pill(phase){ return { display:"inline-block", fontSize:10, padding:"2px 9px", borderRadius:20, background:PHASE_COLORS[phase]+"22", color:PHASE_COLORS[phase], fontWeight:500 }; }

/* ─── APP ────────────────────────────────────────────────── */
export default function App(){
  const [step,     setStep]     = useState(0);
  const [project,  setProject]  = useState({ name:"", location:"", type:"residential", size:"" });
  const [materials,setMaterials]= useState(INIT_MATERIALS);
  const [team,     setTeam]     = useState(INIT_TEAM);
  const [contingency,setCont]   = useState(12);
  const [checks,   setChecks]   = useState({});   // { phase_label: true/false }
  const [riskMit,  setRiskMit]  = useState({});   // { id: true/false }
  const printRef = useRef();

  const sqm       = parseFloat(project.size)||0;
  const typeFactor= PROJECT_TYPES[project.type]?.factor||1;
  const totalDays = INIT_PROCEDURES.reduce((s,p)=>s+p.days,0);

  /* computed materials */
  const computedMats = useMemo(()=> materials.map(m=>{
    const qty  = Math.ceil(sqm * m.perSqm * typeFactor);
    const cost = qty * m.unitCost;
    return {...m, qty, cost};
  }),[materials, sqm, typeFactor]);

  const matTotal  = useMemo(()=> computedMats.reduce((s,m)=>s+m.cost,0), [computedMats]);
  const laborCost = useMemo(()=> team.reduce((s,r)=>s + r.count*r.dailyRate*totalDays*0.3,0), [team,totalDays]);
  const subTotal  = matTotal + laborCost;
  const contAmt   = subTotal*(contingency/100);
  const grandTotal= subTotal + contAmt;
  const totalTeam = team.reduce((s,r)=>s+r.count,0);

  /* computed procedures */
  const procedures = useMemo(()=> INIT_PROCEDURES.map(p=>{
    const base     = p.baseCost * typeFactor * (sqm/200||1);
    const teamCost = team.reduce((s,r)=>s + r.count*r.dailyRate*p.days*p.teamImpact,0);
    return {...p, base, teamCost, total: base+teamCost};
  }),[typeFactor, sqm, team]);

  const procTotal = useMemo(()=>procedures.reduce((s,p)=>s+p.total,0),[procedures]);

  /* Gantt data — sequential start days */
  const ganttData = useMemo(()=>{
    let cursor = 0;
    return INIT_PROCEDURES.map(p=>{
      const item = {...p, start: cursor};
      cursor += p.days;
      return item;
    });
  },[]);

  /* update helpers */
  function setMat(id,field,val){
    setMaterials(prev=>prev.map(m=>m.id===id?{...m,[field]:parseFloat(val)||0}:m));
  }
  function setTeamField(id,field,val){
    setTeam(prev=>prev.map(r=>r.id===id?{...r,[field]:Math.max(0,parseInt(val)||0)}:r));
  }
  function toggleCheck(key){ setChecks(c=>({...c,[key]:!c[key]})); }
  function toggleRisk(id){   setRiskMit(r=>({...r,[id]:!r[id]})); }

  const canNext = step===0 ? (project.name&&project.location&&sqm>0) : true;

  /* print */
  function handlePrint(){
    const w = window.open("","_blank");
    w.document.write(`<html><head><title>${project.name||"Project"} – Construction Report</title>
    <style>
      body{font-family:Georgia,serif;color:#1a1a1a;padding:32px;max-width:900px;margin:0 auto}
      h1{font-size:22px;border-bottom:2px solid #185FA5;padding-bottom:8px}
      h2{font-size:15px;color:#185FA5;margin-top:24px}
      table{width:100%;border-collapse:collapse;font-size:12px;margin-top:8px}
      th{text-align:left;padding:5px 8px;background:#f0f4f8;font-size:11px;border:0.5px solid #ccc}
      td{padding:5px 8px;border:0.5px solid #ccc}
      .total{font-weight:600;background:#f7f7f7}
      .badge{display:inline-block;font-size:10px;padding:2px 8px;border-radius:10px;background:#eee}
      @media print{button{display:none}}
    </style></head><body>
    ${printRef.current?.innerHTML||""}
    <p style="margin-top:32px;font-size:11px;color:#999">Generated by Construction Project Manager · ${new Date().toLocaleDateString()}</p>
    </body></html>`);
    w.document.close();
    setTimeout(()=>w.print(),600);
  }

  /* ── STYLES ── */
  const S = {
    wrap:   { fontFamily:"'Palatino Linotype',Palatino,'Book Antiqua',Georgia,serif", maxWidth:920, margin:"0 auto", padding:"1.25rem 1rem" },
    hdr:    { background:"#0c3a6b", color:"#e8f0f8", borderRadius:"var(--border-radius-lg)", padding:"1.25rem 1.5rem", marginBottom:"1.25rem" },
    hdrT:   { fontSize:24, fontWeight:500, margin:0, letterSpacing:"-0.4px" },
    hdrS:   { fontSize:13, opacity:0.7, margin:"4px 0 0", fontFamily:"var(--font-sans)" },
    stepper:{ display:"flex", flexWrap:"wrap", gap:4, marginBottom:"1.25rem" },
    sBtn:   (a,d)=>({ flex:"1 1 auto", minWidth:80, padding:"7px 4px", fontSize:11, fontFamily:"var(--font-sans)", fontWeight: a?500:400,
      border:"0.5px solid "+(a?"#185FA5":d?"#9FE1CB":"var(--color-border-tertiary)"),
      background: a?"#185FA5":d?"#E1F5EE":"var(--color-background-primary)",
      color: a?"#fff":d?"#0F6E56":"var(--color-text-secondary)",
      borderRadius:"var(--border-radius-md)", cursor: (a||d)?"pointer":"default" }),
    card:   { background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:"1.25rem", marginBottom:"1rem" },
    secT:   { fontSize:14, fontWeight:500, color:"var(--color-text-primary)", fontFamily:"var(--font-sans)", margin:"0 0 12px", borderBottom:"0.5px solid var(--color-border-tertiary)", paddingBottom:8 },
    lbl:    { fontSize:12, color:"var(--color-text-secondary)", fontFamily:"var(--font-sans)", display:"block", marginBottom:4, fontWeight:500 },
    inp:    { width:"100%", boxSizing:"border-box", fontFamily:"var(--font-sans)" },
    g2:     { display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 },
    g3:     { display:"grid", gridTemplateColumns:"repeat(3,minmax(0,1fr))", gap:10 },
    g4:     { display:"grid", gridTemplateColumns:"repeat(4,minmax(0,1fr))", gap:10 },
    mCard:  { background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-md)", padding:"0.9rem", textAlign:"center" },
    mVal:   { fontSize:20, fontWeight:500, color:"var(--color-text-primary)", fontFamily:"var(--font-sans)", margin:0 },
    mLbl:   { fontSize:11, color:"var(--color-text-secondary)", fontFamily:"var(--font-sans)", marginTop:2 },
    tbl:    { width:"100%", borderCollapse:"collapse", fontSize:12, fontFamily:"var(--font-sans)" },
    th:     { textAlign:"left", padding:"5px 8px", fontSize:10, color:"var(--color-text-secondary)", fontWeight:500, borderBottom:"0.5px solid var(--color-border-tertiary)", textTransform:"uppercase", letterSpacing:"0.05em" },
    thR:    { textAlign:"right", padding:"5px 8px", fontSize:10, color:"var(--color-text-secondary)", fontWeight:500, borderBottom:"0.5px solid var(--color-border-tertiary)", textTransform:"uppercase", letterSpacing:"0.05em" },
    td:     { padding:"7px 8px", borderBottom:"0.5px solid var(--color-border-tertiary)", color:"var(--color-text-primary)", verticalAlign:"middle" },
    tdR:    { padding:"7px 8px", borderBottom:"0.5px solid var(--color-border-tertiary)", color:"var(--color-text-primary)", textAlign:"right", fontVariantNumeric:"tabular-nums", verticalAlign:"middle" },
    totRow: { background:"var(--color-background-secondary)", fontWeight:500 },
    nav:    { display:"flex", justifyContent:"space-between", marginTop:"1.25rem", gap:8 },
    btnP:   { background:"#0c3a6b", color:"#fff", border:"none", padding:"9px 22px", borderRadius:"var(--border-radius-md)", fontSize:13, fontFamily:"var(--font-sans)", cursor:"pointer", fontWeight:500 },
    btnS:   { background:"var(--color-background-secondary)", color:"var(--color-text-primary)", border:"0.5px solid var(--color-border-secondary)", padding:"9px 22px", borderRadius:"var(--border-radius-md)", fontSize:13, fontFamily:"var(--font-sans)", cursor:"pointer" },
    cntInp: { width:48, textAlign:"center", fontFamily:"var(--font-sans)", fontSize:12 },
    rateInp:{ width:90, textAlign:"right", fontFamily:"var(--font-sans)", fontSize:12 },
    pmBtn:  (col)=>({ width:22, height:22, border:"0.5px solid var(--color-border-secondary)", borderRadius:4, background:col||"var(--color-background-secondary)", color: col?"#fff":"var(--color-text-primary)", cursor:"pointer", fontSize:13, lineHeight:1, display:"inline-flex", alignItems:"center", justifyContent:"center", padding:0 }),
    note:   { fontSize:11, color:"var(--color-text-secondary)", fontFamily:"var(--font-sans)", marginTop:8 },
  };

  /* ═══════════════════════ RENDER ══════════════════════════ */
  return (
    <div style={S.wrap}>
      {/* HEADER */}
      <div style={S.hdr}>
        <h1 style={S.hdrT}>Construction Project Manager</h1>
        <p style={S.hdrS}>Foundation to finishing — plan, estimate & manage your build · All costs in TZS</p>
      </div>

      {/* STEPPER */}
      <div style={S.stepper}>
        {STEPS.map((s,i)=>(
          <button key={s.id} style={S.sBtn(i===step, i<step)}
            onClick={()=>{ if(i<step) setStep(i); }}>
            {i<step?"✓ ":""}{s.label}
          </button>
        ))}
      </div>

      {/* ── STEP 0: PROJECT SETUP ── */}
      {step===0 && (
        <div>
          <div style={S.card}>
            <p style={S.secT}>Project details</p>
            <div style={S.g2}>
              <div>
                <label style={S.lbl}>Project name</label>
                <input style={S.inp} value={project.name} placeholder="e.g. Moshi Residence" onChange={e=>setProject(p=>({...p,name:e.target.value}))}/>
              </div>
              <div>
                <label style={S.lbl}>Location</label>
                <input style={S.inp} value={project.location} placeholder="e.g. Dodoma, Tanzania" onChange={e=>setProject(p=>({...p,location:e.target.value}))}/>
              </div>
              <div>
                <label style={S.lbl}>Project type</label>
                <select style={S.inp} value={project.type} onChange={e=>setProject(p=>({...p,type:e.target.value}))}>
                  {Object.entries(PROJECT_TYPES).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}
                </select>
              </div>
              <div>
                <label style={S.lbl}>Total floor area (m²)</label>
                <input style={S.inp} type="number" min="1" value={project.size} placeholder="e.g. 350" onChange={e=>setProject(p=>({...p,size:e.target.value}))}/>
              </div>
            </div>
          </div>
          {sqm>0 && (
            <div style={{...S.card, background:"#f0f5fb"}}>
              <div style={S.g4}>
                {[["Floor area",`${fmtN(sqm)} m²`],["Type",PROJECT_TYPES[project.type].label],["Cost factor",`×${typeFactor}`],["Est. duration",`${totalDays} days`]].map(([l,v])=>(
                  <div key={l} style={S.mCard}><p style={S.mVal}>{v}</p><p style={S.mLbl}>{l}</p></div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── STEP 1: MATERIALS ── */}
      {step===1 && (
        <div style={S.card}>
          <p style={S.secT}>Material quantities & costs — {fmtN(sqm)} m² {PROJECT_TYPES[project.type].label}</p>
          <table style={S.tbl}>
            <thead>
              <tr>
                <th style={S.th}>Material</th>
                <th style={S.thR}>Rate / m²</th>
                <th style={{...S.thR,minWidth:100}}>Unit cost (TZS) ✎</th>
                <th style={S.thR}>Qty</th>
                <th style={S.th}>Unit</th>
                <th style={S.thR}>Total (TZS)</th>
              </tr>
            </thead>
            <tbody>
              {computedMats.map(m=>(
                <tr key={m.id}>
                  <td style={S.td}>{m.label}</td>
                  <td style={S.tdR}>{m.perSqm}</td>
                  <td style={S.tdR}>
                    <input type="number" min={0} value={m.unitCost} style={{...S.rateInp,width:110}}
                      onChange={e=>setMat(m.id,"unitCost",e.target.value)}/>
                  </td>
                  <td style={S.tdR}>{fmtN(m.qty)}</td>
                  <td style={S.td}>{m.unit}</td>
                  <td style={S.tdR}>{m.cost.toLocaleString()}</td>
                </tr>
              ))}
              <tr style={S.totRow}>
                <td style={{...S.td,fontWeight:500}} colSpan={5}>Total materials</td>
                <td style={{...S.tdR,fontWeight:500}}>{matTotal.toLocaleString()}</td>
              </tr>
            </tbody>
          </table>
          <p style={S.note}>✎ Edit unit costs to reflect current local market prices. Quantities auto-update.</p>
        </div>
      )}

      {/* ── STEP 2: COST ESTIMATE ── */}
      {step===2 && (
        <div>
          <div style={S.g3}>
            {[["Materials",matTotal],["Labour",laborCost],["Grand Total",grandTotal]].map(([l,v])=>(
              <div key={l} style={{...S.mCard,border:"0.5px solid var(--color-border-tertiary)"}}>
                <p style={{...S.mVal,fontSize:15}}>{tzs(v)}</p>
                <p style={S.mLbl}>{l}</p>
              </div>
            ))}
          </div>
          <div style={{...S.card,marginTop:10}}>
            <p style={S.secT}>Cost breakdown</p>
            <table style={S.tbl}>
              <thead>
                <tr>
                  <th style={S.th}>Item</th>
                  <th style={S.thR}>Amount (TZS)</th>
                  <th style={S.thR}>% of total</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={S.td}>Materials</td>
                  <td style={S.tdR}>{matTotal.toLocaleString()}</td>
                  <td style={S.tdR}>{fmtN(matTotal/grandTotal*100,1)}%</td>
                </tr>
                <tr>
                  <td style={S.td}>Labour ({totalTeam} workers · {totalDays} days)</td>
                  <td style={S.tdR}>{laborCost.toLocaleString()}</td>
                  <td style={S.tdR}>{fmtN(laborCost/grandTotal*100,1)}%</td>
                </tr>
                <tr>
                  <td style={S.td}>
                    <span style={{marginRight:8}}>Contingency</span>
                    <input type="range" min={5} max={25} step={1} value={contingency} onChange={e=>setCont(+e.target.value)} style={{width:80,verticalAlign:"middle"}}/>
                    <span style={{fontWeight:500,marginLeft:8}}>{contingency}%</span>
                  </td>
                  <td style={S.tdR}>{contAmt.toLocaleString()}</td>
                  <td style={S.tdR}>{fmtN(contAmt/grandTotal*100,1)}%</td>
                </tr>
                <tr style={S.totRow}>
                  <td style={{...S.td,fontWeight:500}}>Grand total</td>
                  <td style={{...S.tdR,fontWeight:500}}>{grandTotal.toLocaleString()}</td>
                  <td style={{...S.tdR,fontWeight:500}}>100%</td>
                </tr>
              </tbody>
            </table>
            <p style={S.note}>Cost per m²: <strong style={{color:"var(--color-text-primary)"}}>{tzs(grandTotal/sqm)}</strong> — adjust contingency slider or edit team on the next tab to see live updates.</p>
          </div>
        </div>
      )}

      {/* ── STEP 3: TEAM ── */}
      {step===3 && (
        <div style={S.card}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12,flexWrap:"wrap",gap:8}}>
            <p style={{...S.secT,margin:0,borderBottom:"none",paddingBottom:0}}>Project team</p>
            <div style={{display:"flex",gap:20,fontSize:12,fontFamily:"var(--font-sans)"}}>
              <span style={{color:"var(--color-text-secondary)"}}>Headcount: <strong style={{color:"var(--color-text-primary)"}}>{totalTeam}</strong></span>
              <span style={{color:"var(--color-text-secondary)"}}>Labour cost: <strong style={{color:"var(--color-text-primary)"}}>{tzs(laborCost)}</strong></span>
            </div>
          </div>
          <table style={S.tbl}>
            <thead>
              <tr>
                <th style={S.th}>Role</th>
                <th style={S.th}>Phase</th>
                <th style={{...S.th,textAlign:"center"}}>Count ✎</th>
                <th style={S.thR}>Daily rate (TZS) ✎</th>
                <th style={S.thR}>Cost impact (TZS)</th>
              </tr>
            </thead>
            <tbody>
              {team.map(r=>{
                const rc = r.count*r.dailyRate*totalDays*0.3;
                return (
                  <tr key={r.id}>
                    <td style={S.td}>{r.role}</td>
                    <td style={S.td}><span style={pill(r.phase==="All"?"Pre-Construction":r.phase)}>{r.phase}</span></td>
                    <td style={{...S.td,textAlign:"center"}}>
                      <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:5}}>
                        <button style={S.pmBtn()} onClick={()=>setTeamField(r.id,"count",r.count-1)}>−</button>
                        <input style={S.cntInp} type="number" min={0} value={r.count} onChange={e=>setTeamField(r.id,"count",e.target.value)}/>
                        <button style={S.pmBtn("#0c3a6b")} onClick={()=>setTeamField(r.id,"count",r.count+1)}>+</button>
                      </div>
                    </td>
                    <td style={S.tdR}>
                      <input style={S.rateInp} type="number" min={0} value={r.dailyRate} onChange={e=>setTeamField(r.id,"dailyRate",parseInt(e.target.value)||0)}/>
                    </td>
                    <td style={S.tdR}>{Math.round(rc).toLocaleString()}</td>
                  </tr>
                );
              })}
              <tr style={S.totRow}>
                <td style={{...S.td,fontWeight:500}} colSpan={2}>Total</td>
                <td style={{...S.td,fontWeight:500,textAlign:"center"}}>{totalTeam}</td>
                <td style={S.td}/>
                <td style={{...S.tdR,fontWeight:500}}>{Math.round(laborCost).toLocaleString()}</td>
              </tr>
            </tbody>
          </table>
          <p style={S.note}>Editing headcount or daily rate updates the labour cost and grand total across all steps in real time.</p>
        </div>
      )}

      {/* ── STEP 4: PROCEDURES ── */}
      {step===4 && (
        <div>
          {PHASES.map(ph=>{
            const phProcs = procedures.filter(p=>p.phase===ph);
            if(!phProcs.length) return null;
            const phTotal = phProcs.reduce((s,p)=>s+p.total,0);
            return (
              <div key={ph} style={{...S.card,borderLeft:`3px solid ${PHASE_COLORS[ph]}`,marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                  <p style={{...S.secT,margin:0,borderBottom:"none",paddingBottom:0,color:PHASE_COLORS[ph]}}>{ph}</p>
                  <span style={{fontSize:13,fontWeight:500,fontFamily:"var(--font-sans)"}}>{tzs(phTotal)}</span>
                </div>
                <table style={S.tbl}>
                  <thead>
                    <tr>
                      <th style={S.th}>Procedure</th>
                      <th style={S.th}>Description</th>
                      <th style={S.thR}>Days</th>
                      <th style={S.thR}>Base cost</th>
                      <th style={S.thR}>Team cost</th>
                      <th style={S.thR}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {phProcs.map(p=>(
                      <tr key={p.id}>
                        <td style={{...S.td,fontWeight:500,minWidth:140}}>{p.label}</td>
                        <td style={{...S.td,fontSize:11,color:"var(--color-text-secondary)",minWidth:160}}>{p.desc}</td>
                        <td style={S.tdR}>{p.days}</td>
                        <td style={S.tdR}>{Math.round(p.base).toLocaleString()}</td>
                        <td style={S.tdR}>{Math.round(p.teamCost).toLocaleString()}</td>
                        <td style={{...S.tdR,fontWeight:500}}>{Math.round(p.total).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })}
          <div style={{...S.card,background:"var(--color-background-secondary)"}}>
            <div style={S.g3}>
              {[["Procedure total",procTotal],["Labour (all phases)",laborCost],["Grand total",grandTotal]].map(([l,v])=>(
                <div key={l} style={S.mCard}><p style={{...S.mVal,fontSize:14}}>{tzs(v)}</p><p style={S.mLbl}>{l}</p></div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── STEP 5: TIMELINE / GANTT ── */}
      {step===5 && (
        <div style={S.card}>
          <p style={S.secT}>Phase timeline — {totalDays} day project schedule</p>
          <div style={{overflowX:"auto"}}>
            <div style={{minWidth:640}}>
              {/* header scale */}
              <div style={{display:"flex",marginBottom:4,paddingLeft:180}}>
                {Array.from({length:Math.ceil(totalDays/14)}).map((_,i)=>(
                  <div key={i} style={{width:`${14/totalDays*100}%`,fontSize:10,fontFamily:"var(--font-sans)",color:"var(--color-text-secondary)",minWidth:28,textAlign:"center"}}>
                    {i%2===0?`W${i*2+1}`:""}
                  </div>
                ))}
              </div>
              {ganttData.map(p=>{
                const leftPct = (p.start/totalDays)*100;
                const widthPct= (p.days/totalDays)*100;
                const col = PHASE_COLORS[p.phase];
                return (
                  <div key={p.id} style={{display:"flex",alignItems:"center",marginBottom:5,gap:8}}>
                    <div style={{width:180,fontSize:11,fontFamily:"var(--font-sans)",color:"var(--color-text-primary)",flexShrink:0,textAlign:"right",paddingRight:8,lineHeight:1.3}}>
                      {p.label}
                    </div>
                    <div style={{flex:1,height:22,background:"var(--color-background-secondary)",borderRadius:4,position:"relative"}}>
                      <div style={{position:"absolute",left:`${leftPct}%`,width:`${widthPct}%`,height:"100%",background:col,borderRadius:4,display:"flex",alignItems:"center",justifyContent:"center"}}>
                        <span style={{fontSize:10,color:"#fff",fontFamily:"var(--font-sans)",fontWeight:500,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",padding:"0 4px"}}>{p.days}d</span>
                      </div>
                    </div>
                  </div>
                );
              })}
              {/* phase legend */}
              <div style={{display:"flex",flexWrap:"wrap",gap:8,marginTop:14,paddingLeft:180}}>
                {PHASES.map(ph=>(
                  <span key={ph} style={{display:"flex",alignItems:"center",gap:4,fontSize:10,fontFamily:"var(--font-sans)",color:"var(--color-text-secondary)"}}>
                    <span style={{width:10,height:10,borderRadius:2,background:PHASE_COLORS[ph],display:"inline-block"}}/>
                    {ph}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── STEP 6: RISKS & QUALITY ── */}
      {step===6 && (
        <div>
          <div style={S.card}>
            <p style={S.secT}>Risk register</p>
            <table style={S.tbl}>
              <thead>
                <tr>
                  <th style={{...S.th,width:28}}>Mit.</th>
                  <th style={S.th}>Risk</th>
                  <th style={S.th}>Category</th>
                  <th style={S.th}>Severity</th>
                  <th style={S.th}>Mitigation action</th>
                </tr>
              </thead>
              <tbody>
                {RISKS.map(r=>{
                  const done = riskMit[r.id];
                  const sCol = r.severity==="High"?"#963C1D":r.severity==="Medium"?"#854F0B":"#3B6D11";
                  return (
                    <tr key={r.id} style={{opacity:done?0.5:1}}>
                      <td style={S.td}>
                        <input type="checkbox" checked={!!done} onChange={()=>toggleRisk(r.id)} style={{cursor:"pointer"}}/>
                      </td>
                      <td style={{...S.td,textDecoration:done?"line-through":"none"}}>{r.label}</td>
                      <td style={S.td}><span style={{...pill("Pre-Construction"),color:"#533AB7",background:"#533AB722"}}>{r.cat}</span></td>
                      <td style={S.td}><span style={{...pill("Pre-Construction"),color:sCol,background:sCol+"22"}}>{r.severity}</span></td>
                      <td style={{...S.td,fontSize:11,color:"var(--color-text-secondary)"}}>{r.mitigation}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <p style={S.note}>Check off risks as mitigation actions are completed.</p>
          </div>

          <div style={S.card}>
            <p style={S.secT}>Quality checklists by phase</p>
            {Object.entries(QUALITY_CHECKS).map(([ph,items])=>{
              const doneCount = items.filter((_,i)=>checks[`${ph}_${i}`]).length;
              return (
                <div key={ph} style={{marginBottom:16}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                    <span style={{...pill(ph),fontSize:11,padding:"3px 12px"}}>{ph}</span>
                    <span style={{fontSize:11,fontFamily:"var(--font-sans)",color:"var(--color-text-secondary)"}}>{doneCount}/{items.length} complete</span>
                  </div>
                  {items.map((item,i)=>{
                    const key=`${ph}_${i}`; const done=checks[key];
                    return (
                      <label key={i} style={{display:"flex",alignItems:"flex-start",gap:8,padding:"5px 0",borderBottom:"0.5px solid var(--color-border-tertiary)",cursor:"pointer"}}>
                        <input type="checkbox" checked={!!done} onChange={()=>toggleCheck(key)} style={{marginTop:2,cursor:"pointer"}}/>
                        <span style={{fontSize:12,fontFamily:"var(--font-sans)",color:done?"var(--color-text-secondary)":"var(--color-text-primary)",textDecoration:done?"line-through":"none"}}>{item}</span>
                      </label>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── STEP 7: SUMMARY + PRINT ── */}
      {step===7 && (
        <div>
          <div style={{display:"flex",justifyContent:"flex-end",marginBottom:10}}>
            <button style={{...S.btnP,background:"#3B6D11"}} onClick={handlePrint}>Print / Export PDF</button>
          </div>
          <div ref={printRef}>
            <div style={{...S.card,borderLeft:"4px solid #0c3a6b"}}>
              <p style={S.secT}>Project overview</p>
              <div style={S.g2}>
                {[["Project name",project.name||"—"],["Location",project.location||"—"],["Type",PROJECT_TYPES[project.type].label],["Floor area",`${fmtN(sqm)} m²`],["Total duration",`${totalDays} days`],["Headcount",`${totalTeam} workers`]].map(([l,v])=>(
                  <div key={l} style={{display:"flex",gap:8,fontSize:13,fontFamily:"var(--font-sans)",borderBottom:"0.5px solid var(--color-border-tertiary)",padding:"6px 0"}}>
                    <span style={{color:"var(--color-text-secondary)",minWidth:120}}>{l}</span>
                    <span style={{fontWeight:500}}>{v}</span>
                  </div>
                ))}
              </div>
            </div>

            <div style={S.card}>
              <p style={S.secT}>Financial summary</p>
              <div style={S.g4}>
                {[["Materials",matTotal],["Labour",laborCost],["Contingency",contAmt],["Grand Total",grandTotal]].map(([l,v])=>(
                  <div key={l} style={{...S.mCard,border:"0.5px solid var(--color-border-tertiary)"}}>
                    <p style={{...S.mVal,fontSize:14}}>{tzs(v)}</p>
                    <p style={S.mLbl}>{l}</p>
                  </div>
                ))}
              </div>
              <p style={{...S.note,marginTop:12}}>Cost per m²: <strong>{tzs(grandTotal/sqm)}</strong> · Contingency: {contingency}%</p>
            </div>

            <div style={S.card}>
              <p style={S.secT}>Phase cost breakdown</p>
              <table style={S.tbl}>
                <thead>
                  <tr>
                    <th style={S.th}>Phase</th>
                    <th style={S.thR}>Procedure cost (TZS)</th>
                    <th style={S.thR}>% of procedure total</th>
                  </tr>
                </thead>
                <tbody>
                  {PHASES.map(ph=>{
                    const ph_procs = procedures.filter(p=>p.phase===ph);
                    if(!ph_procs.length) return null;
                    const phT = ph_procs.reduce((s,p)=>s+p.total,0);
                    return (
                      <tr key={ph}>
                        <td style={S.td}><span style={pill(ph)}>{ph}</span></td>
                        <td style={S.tdR}>{Math.round(phT).toLocaleString()}</td>
                        <td style={S.tdR}>{fmtN(phT/procTotal*100,1)}%</td>
                      </tr>
                    );
                  })}
                  <tr style={S.totRow}>
                    <td style={{...S.td,fontWeight:500}}>Total</td>
                    <td style={{...S.tdR,fontWeight:500}}>{Math.round(procTotal).toLocaleString()}</td>
                    <td style={{...S.tdR,fontWeight:500}}>100%</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div style={S.card}>
              <p style={S.secT}>Team summary</p>
              <table style={S.tbl}>
                <thead>
                  <tr><th style={S.th}>Role</th><th style={S.th}>Phase</th><th style={S.thR}>Count</th><th style={S.thR}>Daily rate</th><th style={S.thR}>Cost (TZS)</th></tr>
                </thead>
                <tbody>
                  {team.map(r=>(
                    <tr key={r.id}>
                      <td style={S.td}>{r.role}</td>
                      <td style={S.td}><span style={pill(r.phase==="All"?"Pre-Construction":r.phase)}>{r.phase}</span></td>
                      <td style={S.tdR}>{r.count}</td>
                      <td style={S.tdR}>{r.dailyRate.toLocaleString()}</td>
                      <td style={S.tdR}>{Math.round(r.count*r.dailyRate*totalDays*0.3).toLocaleString()}</td>
                    </tr>
                  ))}
                  <tr style={S.totRow}>
                    <td style={{...S.td,fontWeight:500}} colSpan={2}>Total</td>
                    <td style={{...S.tdR,fontWeight:500}}>{totalTeam}</td>
                    <td style={S.td}/>
                    <td style={{...S.tdR,fontWeight:500}}>{Math.round(laborCost).toLocaleString()}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div style={{...S.card,marginTop:10,background:"var(--color-background-secondary)",textAlign:"center"}}>
            <p style={{fontFamily:"var(--font-sans)",fontSize:13,color:"var(--color-text-secondary)",margin:0}}>
              All estimates are indicative. Engage a quantity surveyor for final BOQ. · {new Date().toLocaleDateString("en-TZ")}
            </p>
          </div>
        </div>
      )}

      {/* NAV */}
      <div style={S.nav}>
        {step>0
          ? <button style={S.btnS} onClick={()=>setStep(s=>s-1)}>← Back</button>
          : <span/>}
        {step<STEPS.length-1
          ? <button style={{...S.btnP,opacity:canNext?1:0.4}} disabled={!canNext} onClick={()=>setStep(s=>s+1)}>
              Next: {STEPS[step+1].label} →
            </button>
          : <button style={S.btnP} onClick={()=>{setStep(0);setProject({name:"",location:"",type:"residential",size:""});}}>
              New project ↺
            </button>}
      </div>
    </div>
  );
}
